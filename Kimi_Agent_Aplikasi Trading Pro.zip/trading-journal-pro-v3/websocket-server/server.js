const WebSocket = require('ws');
const http = require('http');

// Create HTTP server
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'WebSocket server running' }));
});

// Create WebSocket server
const wss = new WebSocket.Server({ server });

// Mock price data
const pairs = {
  'XAUUSD': { bid: 2045.32, ask: 2045.50, spread: 0.18 },
  'BTCUSD': { bid: 42150.80, ask: 42163.30, spread: 12.5 },
  'EURUSD': { bid: 1.0850, ask: 1.0852, spread: 0.2 },
  'GBPUSD': { bid: 1.2650, ask: 1.2653, spread: 0.3 },
};

// Simulate price updates
function updatePrices() {
  Object.keys(pairs).forEach(pair => {
    const change = (Math.random() - 0.5) * 0.001;
    pairs[pair].bid *= (1 + change);
    pairs[pair].ask = pairs[pair].bid + pairs[pair].spread;
  });
}

// Broadcast prices to all clients
function broadcastPrices() {
  updatePrices();
  const message = JSON.stringify({
    type: 'PRICE_UPDATE',
    data: pairs,
    timestamp: Date.now()
  });
  
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// WebSocket connection handler
wss.on('connection', (ws) => {
  console.log('New client connected');
  
  // Send initial prices
  ws.send(JSON.stringify({
    type: 'PRICE_UPDATE',
    data: pairs,
    timestamp: Date.now()
  }));
  
  // Handle messages from client
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      console.log('Received:', data);
      
      // Handle subscription requests
      if (data.type === 'SUBSCRIBE') {
        ws.send(JSON.stringify({
          type: 'SUBSCRIBED',
          pairs: data.pairs
        }));
      }
    } catch (err) {
      console.error('Invalid message:', err);
    }
  });
  
  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

// Broadcast prices every second
setInterval(broadcastPrices, 1000);

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`WebSocket server running on port ${PORT}`);
});
