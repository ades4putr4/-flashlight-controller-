# Trading Journal Pro V3.5

A comprehensive, production-ready trading planning and journal application with real-time signals, MetaTrader 5 integration, and advanced analytics.

![Version](https://img.shields.io/badge/version-3.5.0-blue)
![Next.js](https://img.shields.io/badge/Next.js-14-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-blue)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green)

## Features

### Core Modules

1. **Authentication & User System**
   - JWT-based authentication
   - Multi-account support
   - Account types: Personal, Funded, Prop Firm

2. **Trading Plan Module**
   - Pre-entry planning with validation
   - Auto lot size calculation
   - RR ratio calculation
   - Setup quality scoring
   - Screenshot upload

3. **Trade Journal Module**
   - Post-trade logging
   - AI trade grading (A-D)
   - Psychology tracking
   - Mistake tagging
   - Performance analytics

4. **Real-time Signal Engine**
   - XAUUSD & BTCUSD M15 signals
   - Smart Money Concepts (SMC)
   - BOS, CHoCH, FVG detection
   - Signal strength calculation
   - Risk filtering

5. **MetaTrader 5 Sync**
   - Python bridge service
   - Auto trade import
   - Balance/equity sync
   - Position tracking

6. **Risk Management Engine**
   - Daily/weekly loss limits
   - Max drawdown tracking
   - Trading block system
   - Risk heat indicator

7. **Advanced Analytics**
   - Equity curve
   - Win rate by setup/pair
   - Session heatmap
   - Psychology impact analysis
   - Signal accuracy tracking

8. **Money Management Simulator**
   - Fixed risk simulation
   - Compounding projection
   - Risk of ruin calculation

## Tech Stack

### Frontend
- Next.js 14 (App Router)
- TypeScript 5
- Tailwind CSS
- ShadCN UI
- Recharts
- Zustand (State Management)
- Lightweight Charts

### Backend
- Supabase (Auth + PostgreSQL)
- Row Level Security
- Real-time subscriptions
- Storage for screenshots

### WebSocket Server
- Node.js
- WS library
- Real-time price feed

### MT5 Bridge
- Python 3.9+
- MetaTrader5 API
- Pandas for data processing

## Project Structure

```
trading-journal-pro-v3/
├── src/
│   ├── app/                    # Next.js app router
│   │   ├── dashboard/
│   │   ├── login/
│   │   ├── register/
│   │   ├── signals/
│   │   ├── trading-plan/
│   │   ├── trade-log/
│   │   ├── analytics/
│   │   ├── risk-management/
│   │   ├── mm-simulator/
│   │   └── settings/
│   ├── components/
│   │   ├── ui/                 # ShadCN UI components
│   │   ├── dashboard/
│   │   ├── signals/
│   │   ├── trading/
│   │   └── analytics/
│   ├── lib/
│   │   ├── supabase.ts         # Supabase client
│   │   └── utils.ts            # Utility functions
│   ├── store/
│   │   └── index.ts            # Zustand stores
│   ├── types/
│   │   ├── index.ts            # TypeScript types
│   │   └── database.ts         # Database types
│   └── hooks/                  # Custom React hooks
├── websocket-server/
│   ├── server.js               # WebSocket server
│   └── package.json
├── mt5-bridge/
│   ├── mt5_bridge.py           # MT5 Python bridge
│   └── requirements.txt
├── database-schema.sql         # Complete SQL schema
└── README.md
```

## Quick Start

### 1. Clone and Install

```bash
git clone <repository-url>
cd trading-journal-pro-v3
npm install
```

### 2. Environment Variables

Create `.env.local`:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# WebSocket
NEXT_PUBLIC_WS_URL=ws://localhost:3001

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. Database Setup

1. Create a new Supabase project
2. Run the SQL schema in `database-schema.sql`
3. Enable Row Level Security policies

### 4. Run Development Server

```bash
# Frontend
npm run dev

# WebSocket Server (separate terminal)
cd websocket-server
npm install
npm start

# MT5 Bridge (optional, separate terminal)
cd mt5-bridge
pip install -r requirements.txt
python mt5_bridge.py
```

### 5. Build for Production

```bash
npm run build
```

## Deployment

### Vercel (Frontend)

```bash
npm i -g vercel
vercel --prod
```

### Supabase (Database)

1. Connect your project to Supabase
2. Run database migrations
3. Configure authentication providers

### Railway/Render (WebSocket Server)

```bash
cd websocket-server
# Deploy to Railway
railway login
railway init
railway up
```

### VPS (MT5 Bridge)

1. Set up a Windows VPS with MT5 installed
2. Install Python and dependencies
3. Run the bridge as a Windows service

## Signal Engine Logic

### Confluence Factors

1. **Structure Analysis**
   - Break of Structure (BOS)
   - Change of Character (CHoCH)
   - Liquidity sweeps
   - Fair Value Gaps (FVG)

2. **Indicator Confirmation**
   - RSI divergence
   - MACD momentum
   - ATR volatility filter

3. **Risk Filters**
   - Minimum RR 1:2
   - Spread check
   - ADR < 90%
   - News filter (±30 min)

### Signal Output

```typescript
interface Signal {
  pair: string
  direction: 'Buy' | 'Sell'
  entry: number
  stopLoss: number
  takeProfit1: number
  takeProfit2?: number
  rr: number
  setupQuality: number  // 0-100
  signalStrength: number  // 0-100
  confluences: string[]
}
```

## Risk Calculator

### Lot Size Formula

```
Lot Size = (Balance × Risk%) / (SL in pips × Pip Value)
```

### Risk Validation

- Max risk per trade: 1-2%
- Max daily loss: 3%
- Max weekly loss: 5%
- Max drawdown: 10%

## AI Trade Grading

### Grade Calculation

| Factor | Weight | Max Points |
|--------|--------|------------|
| Rules Followed | 40% | 40 |
| Setup Quality | 30% | 30 |
| Emotional State | 15% | 15 |
| RR Achieved | 15% | 15 |

### Grade Scale

- **A**: 90-100 points
- **B**: 75-89 points
- **C**: 60-74 points
- **D**: < 60 points

## API Endpoints

### Supabase REST API

```
GET /rest/v1/trades
GET /rest/v1/trade_plans
GET /rest/v1/signals
GET /rest/v1/accounts
POST /rest/v1/trades
PATCH /rest/v1/trades/:id
```

### WebSocket Events

```javascript
// Client -> Server
{ type: 'SUBSCRIBE', pairs: ['XAUUSD', 'BTCUSD'] }

// Server -> Client
{ type: 'PRICE_UPDATE', data: { XAUUSD: { bid, ask, spread } } }
{ type: 'NEW_SIGNAL', signal: { ... } }
```

## Environment Variables Reference

| Variable | Description | Required |
|----------|-------------|----------|
| NEXT_PUBLIC_SUPABASE_URL | Supabase project URL | Yes |
| NEXT_PUBLIC_SUPABASE_ANON_KEY | Supabase anon key | Yes |
| NEXT_PUBLIC_WS_URL | WebSocket server URL | Yes |
| SUPABASE_SERVICE_KEY | Service role key (backend) | Yes |
| MT5_LOGIN | MT5 account number | No |
| MT5_PASSWORD | MT5 password | No |
| MT5_SERVER | MT5 broker server | No |

## Troubleshooting

### Common Issues

1. **Build errors**
   - Check Node.js version (18+)
   - Clear `.next` cache: `rm -rf .next`

2. **Database connection**
   - Verify Supabase credentials
   - Check RLS policies

3. **WebSocket not connecting**
   - Ensure WebSocket server is running
   - Check firewall settings

4. **MT5 bridge errors**
   - Verify MT5 is running
   - Check Python version (3.9+)

## License

MIT License - See LICENSE file for details

## Support

For support and feature requests, please open an issue on GitHub.

---

Built with ❤️ for traders who take their craft seriously.
