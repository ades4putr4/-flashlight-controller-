-- =====================================================
-- TRADING JOURNAL PRO V3.5 - DATABASE SCHEMA
-- Supabase PostgreSQL
-- =====================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- 1. USERS TABLE (extends Supabase auth.users)
-- =====================================================
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email VARCHAR(255) UNIQUE NOT NULL,
  full_name VARCHAR(255),
  avatar_url TEXT,
  timezone VARCHAR(50) DEFAULT 'UTC',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 2. ACCOUNTS TABLE (Multi-account support)
-- =====================================================
CREATE TABLE accounts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  account_type VARCHAR(20) NOT NULL CHECK (account_type IN ('Personal', 'Funded', 'Prop')),
  broker VARCHAR(100),
  account_number VARCHAR(50),
  
  -- Capital Settings
  initial_balance DECIMAL(15, 2) NOT NULL DEFAULT 10000,
  current_balance DECIMAL(15, 2) NOT NULL DEFAULT 10000,
  equity DECIMAL(15, 2) NOT NULL DEFAULT 10000,
  leverage INTEGER DEFAULT 100,
  currency VARCHAR(3) DEFAULT 'USD',
  
  -- Risk Settings
  risk_per_trade DECIMAL(5, 2) DEFAULT 1.00,
  max_daily_loss DECIMAL(5, 2) DEFAULT 3.00,
  max_weekly_loss DECIMAL(5, 2) DEFAULT 5.00,
  max_trailing_drawdown DECIMAL(5, 2) DEFAULT 10.00,
  max_open_trades INTEGER DEFAULT 3,
  
  -- Prop Firm Settings
  profit_target DECIMAL(5, 2),
  time_limit_days INTEGER,
  is_active BOOLEAN DEFAULT true,
  is_funded BOOLEAN DEFAULT false,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 3. TRADE PLANS TABLE (Pre-entry planning)
-- =====================================================
CREATE TABLE trade_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  
  -- Trade Details
  pair VARCHAR(20) NOT NULL,
  timeframe VARCHAR(10) NOT NULL,
  setup_type VARCHAR(50) NOT NULL,
  direction VARCHAR(10) NOT NULL CHECK (direction IN ('Buy', 'Sell')),
  
  -- Price Levels
  entry_price DECIMAL(15, 5) NOT NULL,
  stop_loss DECIMAL(15, 5) NOT NULL,
  take_profit_1 DECIMAL(15, 5) NOT NULL,
  take_profit_2 DECIMAL(15, 5),
  take_profit_3 DECIMAL(15, 5),
  
  -- Risk Calculation
  risk_percent DECIMAL(5, 2) NOT NULL,
  lot_size DECIMAL(10, 2) NOT NULL,
  rr_ratio DECIMAL(5, 2) NOT NULL,
  potential_profit DECIMAL(15, 2),
  potential_loss DECIMAL(15, 2),
  
  -- Analysis
  setup_quality INTEGER CHECK (setup_quality >= 0 AND setup_quality <= 100),
  market_bias VARCHAR(20) CHECK (market_bias IN ('Bullish', 'Bearish', 'Neutral')),
  news_impact VARCHAR(10) DEFAULT 'None' CHECK (news_impact IN ('None', 'Low', 'Medium', 'High')),
  
  -- Validation
  adr_percent DECIMAL(5, 2),
  spread_pips DECIMAL(8, 2),
  is_valid_rr BOOLEAN DEFAULT false,
  is_within_daily_loss BOOLEAN DEFAULT true,
  
  -- Media
  screenshot_before TEXT,
  
  -- Checklist
  checklist JSONB DEFAULT '[]'::jsonb,
  
  -- Notes
  analysis_notes TEXT,
  
  -- Status
  status VARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Active', 'Executed', 'Cancelled')),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  planned_at TIMESTAMP WITH TIME ZONE
);

-- =====================================================
-- 4. TRADES TABLE (Executed trades / Journal)
-- =====================================================
CREATE TABLE trades (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  plan_id UUID REFERENCES trade_plans(id) ON DELETE SET NULL,
  
  -- Trade Details
  pair VARCHAR(20) NOT NULL,
  timeframe VARCHAR(10) NOT NULL,
  setup_type VARCHAR(50) NOT NULL,
  direction VARCHAR(10) NOT NULL,
  
  -- Entry/Exit
  entry_price DECIMAL(15, 5) NOT NULL,
  exit_price DECIMAL(15, 5),
  stop_loss DECIMAL(15, 5) NOT NULL,
  take_profit_1 DECIMAL(15, 5) NOT NULL,
  
  -- Position
  lot_size DECIMAL(10, 2) NOT NULL,
  risk_percent DECIMAL(5, 2) NOT NULL,
  rr_planned DECIMAL(5, 2),
  rr_achieved DECIMAL(5, 2),
  
  -- Result
  result VARCHAR(20) CHECK (result IN ('Win', 'Loss', 'BreakEven')),
  profit_loss DECIMAL(15, 2),
  profit_loss_pips DECIMAL(10, 2),
  profit_loss_percent DECIMAL(8, 4),
  
  -- Duration
  opened_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  closed_at TIMESTAMP WITH TIME ZONE,
  duration_minutes INTEGER,
  
  -- Psychology
  emotion VARCHAR(20) CHECK (emotion IN ('Calm', 'FOMO', 'Revenge', 'Overconfidence', 'Fear', 'Hesitation')),
  rules_followed BOOLEAN DEFAULT true,
  
  -- AI Grading
  grade VARCHAR(2) CHECK (grade IN ('A', 'B', 'C', 'D')),
  grade_score INTEGER CHECK (grade_score >= 0 AND grade_score <= 100),
  
  -- Evaluation
  mistake_tags JSONB DEFAULT '[]'::jsonb,
  evaluation_notes TEXT,
  lessons_learned TEXT,
  
  -- Media
  screenshot_before TEXT,
  screenshot_after TEXT,
  
  -- Signal Reference
  signal_id UUID,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 5. SIGNALS TABLE (Real-time signals)
-- =====================================================
CREATE TABLE signals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  
  -- Signal Info
  pair VARCHAR(20) NOT NULL,
  timeframe VARCHAR(10) NOT NULL,
  direction VARCHAR(10) NOT NULL CHECK (direction IN ('Buy', 'Sell')),
  
  -- Price Levels
  entry_price DECIMAL(15, 5) NOT NULL,
  stop_loss DECIMAL(15, 5) NOT NULL,
  take_profit_1 DECIMAL(15, 5) NOT NULL,
  take_profit_2 DECIMAL(15, 5),
  take_profit_3 DECIMAL(15, 5),
  
  -- Analysis
  rr_ratio DECIMAL(5, 2) NOT NULL,
  setup_quality INTEGER CHECK (setup_quality >= 0 AND setup_quality <= 100),
  signal_strength INTEGER CHECK (signal_strength >= 0 AND signal_strength <= 100),
  
  -- Market Condition
  market_condition VARCHAR(50),
  trend_direction VARCHAR(20),
  volatility_state VARCHAR(20),
  
  -- Confluences
  confluences JSONB DEFAULT '[]'::jsonb,
  
  -- Filters
  spread_pips DECIMAL(8, 2),
  adr_percent DECIMAL(5, 2),
  session VARCHAR(20),
  
  -- Status
  status VARCHAR(20) DEFAULT 'Active' CHECK (status IN ('Active', 'Triggered', 'Hit TP1', 'Hit TP2', 'Hit TP3', 'Hit SL', 'Expired', 'Cancelled')),
  
  -- Result Tracking
  result VARCHAR(20),
  pips_gained DECIMAL(10, 2),
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  triggered_at TIMESTAMP WITH TIME ZONE,
  closed_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  
  -- Candle close reference
  candle_close_time TIMESTAMP WITH TIME ZONE
);

-- =====================================================
-- 6. SIGNAL STATS TABLE (Signal performance)
-- =====================================================
CREATE TABLE signal_stats (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  pair VARCHAR(20) NOT NULL,
  timeframe VARCHAR(10) NOT NULL,
  
  -- Stats
  total_signals INTEGER DEFAULT 0,
  winning_signals INTEGER DEFAULT 0,
  losing_signals INTEGER DEFAULT 0,
  
  -- Accuracy
  accuracy_rate DECIMAL(5, 2),
  avg_pips_per_signal DECIMAL(8, 2),
  
  -- By direction
  buy_signals INTEGER DEFAULT 0,
  buy_wins INTEGER DEFAULT 0,
  sell_signals INTEGER DEFAULT 0,
  sell_wins INTEGER DEFAULT 0,
  
  -- By strength
  strong_signals INTEGER DEFAULT 0,
  strong_wins INTEGER DEFAULT 0,
  moderate_signals INTEGER DEFAULT 0,
  moderate_wins INTEGER DEFAULT 0,
  weak_signals INTEGER DEFAULT 0,
  weak_wins INTEGER DEFAULT 0,
  
  -- Period
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(pair, timeframe, period_start)
);

-- =====================================================
-- 7. LIVE PRICES TABLE (Price feed cache)
-- =====================================================
CREATE TABLE live_prices (
  pair VARCHAR(20) PRIMARY KEY,
  bid DECIMAL(15, 5) NOT NULL,
  ask DECIMAL(15, 5) NOT NULL,
  spread DECIMAL(8, 2) NOT NULL,
  change DECIMAL(8, 2),
  change_percent DECIMAL(5, 2),
  high_24h DECIMAL(15, 5),
  low_24h DECIMAL(15, 5),
  adr DECIMAL(10, 2),
  adr_percent DECIMAL(5, 2),
  volume DECIMAL(20, 2),
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 8. RISK RULES TABLE (User risk configuration)
-- =====================================================
CREATE TABLE risk_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  
  -- Risk Limits
  max_risk_per_trade DECIMAL(5, 2) DEFAULT 1.00,
  max_daily_loss DECIMAL(5, 2) DEFAULT 3.00,
  max_weekly_loss DECIMAL(5, 2) DEFAULT 5.00,
  max_monthly_loss DECIMAL(5, 2) DEFAULT 10.00,
  max_trailing_drawdown DECIMAL(5, 2) DEFAULT 10.00,
  max_open_trades INTEGER DEFAULT 3,
  
  -- Daily tracking
  daily_loss_today DECIMAL(15, 2) DEFAULT 0,
  weekly_loss_this_week DECIMAL(15, 2) DEFAULT 0,
  monthly_loss_this_month DECIMAL(15, 2) DEFAULT 0,
  current_drawdown DECIMAL(5, 2) DEFAULT 0,
  
  -- Status
  trading_blocked BOOLEAN DEFAULT false,
  block_reason TEXT,
  blocked_until TIMESTAMP WITH TIME ZONE,
  
  -- Alerts
  alert_on_daily_70_percent BOOLEAN DEFAULT true,
  alert_on_daily_90_percent BOOLEAN DEFAULT true,
  alert_on_weekly_70_percent BOOLEAN DEFAULT true,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 9. TRADING RULES TABLE (User's personal rules)
-- =====================================================
CREATE TABLE trading_rules (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  rule TEXT NOT NULL,
  category VARCHAR(50) DEFAULT 'General',
  priority INTEGER DEFAULT 1,
  is_active BOOLEAN DEFAULT true,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 10. WEEKLY REVIEWS TABLE
-- =====================================================
CREATE TABLE weekly_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  
  week_start DATE NOT NULL,
  week_end DATE NOT NULL,
  
  -- Performance
  starting_balance DECIMAL(15, 2),
  ending_balance DECIMAL(15, 2),
  total_trades INTEGER DEFAULT 0,
  winning_trades INTEGER DEFAULT 0,
  losing_trades INTEGER DEFAULT 0,
  
  -- Review Content
  what_went_well TEXT,
  what_to_improve TEXT,
  discipline_rating INTEGER CHECK (discipline_rating >= 1 AND discipline_rating <= 10),
  goals_for_next_week TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, account_id, week_start)
);

-- =====================================================
-- 11. MONTHLY REFLECTIONS TABLE
-- =====================================================
CREATE TABLE monthly_reflections (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  
  month DATE NOT NULL,
  
  -- Performance
  starting_balance DECIMAL(15, 2),
  ending_balance DECIMAL(15, 2),
  total_profit_loss DECIMAL(15, 2),
  return_percent DECIMAL(8, 4),
  
  -- Review Content
  best_trade TEXT,
  worst_trade TEXT,
  emotional_patterns TEXT,
  strategy_adjustments TEXT,
  goals_progress TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, account_id, month)
);

-- =====================================================
-- 12. MM SIMULATIONS TABLE (Money Management)
-- =====================================================
CREATE TABLE mm_simulations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  
  name VARCHAR(100) NOT NULL,
  strategy_type VARCHAR(50) NOT NULL CHECK (strategy_type IN ('Fixed Risk', 'Compounding', 'Martingale', 'Anti-Martingale', 'Kelly Criterion')),
  
  -- Parameters
  initial_capital DECIMAL(15, 2) NOT NULL,
  risk_per_trade DECIMAL(5, 2) NOT NULL,
  win_rate DECIMAL(5, 2) NOT NULL,
  avg_rr DECIMAL(5, 2) NOT NULL,
  num_trades INTEGER NOT NULL,
  
  -- Results
  final_capital DECIMAL(15, 2),
  total_return DECIMAL(8, 4),
  max_drawdown DECIMAL(5, 2),
  risk_of_ruin DECIMAL(5, 2),
  simulation_data JSONB,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- 13. MT5 SYNC LOGS TABLE
-- =====================================================
CREATE TABLE mt5_sync_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  
  sync_type VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL,
  records_synced INTEGER DEFAULT 0,
  error_message TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================
CREATE INDEX idx_trades_user_id ON trades(user_id);
CREATE INDEX idx_trades_account_id ON trades(account_id);
CREATE INDEX idx_trades_created_at ON trades(created_at);
CREATE INDEX idx_trades_pair ON trades(pair);
CREATE INDEX idx_trades_result ON trades(result);

CREATE INDEX idx_trade_plans_user_id ON trade_plans(user_id);
CREATE INDEX idx_trade_plans_status ON trade_plans(status);

CREATE INDEX idx_signals_pair ON signals(pair);
CREATE INDEX idx_signals_status ON signals(status);
CREATE INDEX idx_signals_created_at ON signals(created_at);

CREATE INDEX idx_accounts_user_id ON accounts(user_id);
CREATE INDEX idx_accounts_is_active ON accounts(is_active);

-- =====================================================
-- ROW LEVEL SECURITY POLICIES
-- =====================================================
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE trade_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE risk_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE trading_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE weekly_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE monthly_reflections ENABLE ROW LEVEL SECURITY;
ALTER TABLE mm_simulations ENABLE ROW LEVEL SECURITY;
ALTER TABLE mt5_sync_logs ENABLE ROW LEVEL SECURITY;

-- Users can only see their own data
CREATE POLICY "Users can view own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can view own accounts" ON accounts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own accounts" ON accounts FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own trades" ON trades FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own trades" ON trades FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own plans" ON trade_plans FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own plans" ON trade_plans FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can view own risk rules" ON risk_rules FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can manage own risk rules" ON risk_rules FOR ALL USING (auth.uid() = user_id);

-- Signals are public (read-only)
CREATE POLICY "Signals are public" ON signals FOR SELECT USING (true);

-- =====================================================
-- FUNCTIONS & TRIGGERS
-- =====================================================

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply update trigger to all tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_accounts_updated_at BEFORE UPDATE ON accounts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trades_updated_at BEFORE UPDATE ON trades
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trade_plans_updated_at BEFORE UPDATE ON trade_plans
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to calculate trade grade
CREATE OR REPLACE FUNCTION calculate_trade_grade(
  p_rules_followed BOOLEAN,
  p_setup_quality INTEGER,
  p_emotion VARCHAR,
  p_rr_achieved DECIMAL
) RETURNS VARCHAR AS $$
DECLARE
  v_score INTEGER := 0;
BEGIN
  -- Rules followed (40 points)
  IF p_rules_followed THEN
    v_score := v_score + 40;
  END IF;
  
  -- Setup quality (30 points)
  v_score := v_score + (p_setup_quality * 0.3);
  
  -- Emotion (15 points)
  IF p_emotion = 'Calm' THEN
    v_score := v_score + 15;
  ELSIF p_emotion IN ('Overconfidence', 'Hesitation') THEN
    v_score := v_score + 8;
  END IF;
  
  -- RR achieved (15 points)
  IF p_rr_achieved >= 3 THEN
    v_score := v_score + 15;
  ELSIF p_rr_achieved >= 2 THEN
    v_score := v_score + 10;
  ELSIF p_rr_achieved >= 1 THEN
    v_score := v_score + 5;
  END IF;
  
  -- Return grade
  IF v_score >= 90 THEN
    RETURN 'A';
  ELSIF v_score >= 75 THEN
    RETURN 'B';
  ELSIF v_score >= 60 THEN
    RETURN 'C';
  ELSE
    RETURN 'D';
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Function to update account equity after trade
CREATE OR REPLACE FUNCTION update_account_equity()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.result IS NOT NULL AND NEW.profit_loss IS NOT NULL THEN
    UPDATE accounts
    SET 
      current_balance = current_balance + NEW.profit_loss,
      equity = equity + NEW.profit_loss,
      updated_at = NOW()
    WHERE id = NEW.account_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER after_trade_insert_update_equity
  AFTER INSERT OR UPDATE ON trades
  FOR EACH ROW
  EXECUTE FUNCTION update_account_equity();
