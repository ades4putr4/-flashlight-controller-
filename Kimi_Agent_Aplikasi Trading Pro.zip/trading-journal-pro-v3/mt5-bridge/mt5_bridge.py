"""
MT5 Bridge Service for Trading Journal Pro V3.5
Connects to MetaTrader 5 and syncs trading data
"""

import MetaTrader5 as mt5
import pandas as pd
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import requests
import os
from dotenv import load_dotenv

load_dotenv()

class MT5Bridge:
    def __init__(self):
        self.connected = False
        self.account_info = None
        self.supabase_url = os.getenv('SUPABASE_URL')
        self.supabase_key = os.getenv('SUPABASE_SERVICE_KEY')
        
    def connect(self, login: int = None, password: str = None, server: str = None) -> bool:
        """Connect to MT5 terminal"""
        try:
            if not mt5.initialize():
                print("MT5 initialization failed")
                return False
            
            if login and password and server:
                authorized = mt5.login(login, password, server)
                if not authorized:
                    print(f"Login failed: {mt5.last_error()}")
                    return False
            
            self.connected = True
            self.account_info = mt5.account_info()
            print(f"Connected to MT5 - Account: {self.account_info.login}")
            return True
            
        except Exception as e:
            print(f"Connection error: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from MT5"""
        mt5.shutdown()
        self.connected = False
        print("Disconnected from MT5")
    
    def get_account_info(self) -> Dict:
        """Get account information"""
        if not self.connected:
            return {}
        
        info = mt5.account_info()
        return {
            'login': info.login,
            'balance': info.balance,
            'equity': info.equity,
            'profit': info.profit,
            'margin': info.margin,
            'margin_free': info.margin_free,
            'margin_level': info.margin_level,
            'currency': info.currency,
            'leverage': info.leverage,
        }
    
    def get_open_positions(self) -> List[Dict]:
        """Get all open positions"""
        if not self.connected:
            return []
        
        positions = mt5.positions_get()
        if positions is None:
            return []
        
        result = []
        for pos in positions:
            result.append({
                'ticket': pos.ticket,
                'symbol': pos.symbol,
                'type': 'Buy' if pos.type == mt5.ORDER_TYPE_BUY else 'Sell',
                'volume': pos.volume,
                'open_price': pos.price_open,
                'current_price': pos.price_current,
                'sl': pos.sl,
                'tp': pos.tp,
                'profit': pos.profit,
                'swap': pos.swap,
                'open_time': datetime.fromtimestamp(pos.time).isoformat(),
            })
        return result
    
    def get_trade_history(self, days: int = 30) -> List[Dict]:
        """Get trade history for specified days"""
        if not self.connected:
            return []
        
        from_date = datetime.now() - timedelta(days=days)
        to_date = datetime.now()
        
        deals = mt5.history_deals_get(from_date, to_date)
        if deals is None:
            return []
        
        result = []
        for deal in deals:
            result.append({
                'ticket': deal.ticket,
                'order': deal.order,
                'symbol': deal.symbol,
                'type': 'Buy' if deal.type == mt5.DEAL_TYPE_BUY else 'Sell',
                'volume': deal.volume,
                'price': deal.price,
                'profit': deal.profit,
                'commission': deal.commission,
                'swap': deal.swap,
                'time': datetime.fromtimestamp(deal.time).isoformat(),
            })
        return result
    
    def get_symbols(self) -> List[str]:
        """Get all available symbols"""
        if not self.connected:
            return []
        
        symbols = mt5.symbols_get()
        return [s.name for s in symbols]
    
    def get_symbol_info(self, symbol: str) -> Dict:
        """Get symbol information"""
        if not self.connected:
            return {}
        
        info = mt5.symbol_info(symbol)
        if info is None:
            return {}
        
        return {
            'name': info.name,
            'bid': info.bid,
            'ask': info.ask,
            'spread': info.spread,
            'point': info.point,
            'digits': info.digits,
            'trade_allowed': info.trade_allowed,
            'volume_min': info.volume_min,
            'volume_max': info.volume_max,
            'volume_step': info.volume_step,
        }
    
    def get_rates(self, symbol: str, timeframe: int, count: int = 100) -> List[Dict]:
        """Get price rates/candles"""
        if not self.connected:
            return []
        
        rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, count)
        if rates is None:
            return []
        
        result = []
        for rate in rates:
            result.append({
                'time': datetime.fromtimestamp(rate[0]).isoformat(),
                'open': rate[1],
                'high': rate[2],
                'low': rate[3],
                'close': rate[4],
                'volume': rate[5],
            })
        return result
    
    def sync_to_supabase(self, user_id: str, account_id: str):
        """Sync MT5 data to Supabase"""
        try:
            # Get account info
            account_info = self.get_account_info()
            
            # Get open positions
            positions = self.get_open_positions()
            
            # Get trade history
            history = self.get_trade_history()
            
            # Prepare data
            sync_data = {
                'user_id': user_id,
                'account_id': account_id,
                'mt5_account': account_info,
                'positions': positions,
                'history': history,
                'synced_at': datetime.now().isoformat(),
            }
            
            # Send to Supabase
            headers = {
                'apikey': self.supabase_key,
                'Authorization': f'Bearer {self.supabase_key}',
                'Content-Type': 'application/json',
            }
            
            response = requests.post(
                f'{self.supabase_url}/rest/v1/mt5_sync_logs',
                headers=headers,
                json={
                    'user_id': user_id,
                    'account_id': account_id,
                    'sync_type': 'full_sync',
                    'status': 'success',
                    'records_synced': len(history),
                }
            )
            
            print(f"Sync completed: {len(history)} trades synced")
            return True
            
        except Exception as e:
            print(f"Sync error: {e}")
            return False
    
    def export_to_csv(self, filename: str = None):
        """Export trade history to CSV"""
        history = self.get_trade_history()
        if not history:
            print("No trade history to export")
            return
        
        df = pd.DataFrame(history)
        
        if filename is None:
            filename = f"mt5_trades_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        df.to_csv(filename, index=False)
        print(f"Exported {len(history)} trades to {filename}")


def main():
    """Main function for running the bridge"""
    bridge = MT5Bridge()
    
    # Connect to MT5
    if not bridge.connect():
        print("Failed to connect to MT5")
        return
    
    try:
        # Print account info
        account_info = bridge.get_account_info()
        print(f"\nAccount Info:")
        print(f"  Balance: {account_info.get('balance')}")
        print(f"  Equity: {account_info.get('equity')}")
        print(f"  Profit: {account_info.get('profit')}")
        
        # Print open positions
        positions = bridge.get_open_positions()
        print(f"\nOpen Positions: {len(positions)}")
        for pos in positions:
            print(f"  {pos['symbol']} {pos['type']} - Profit: {pos['profit']}")
        
        # Print recent trades
        history = bridge.get_trade_history(days=7)
        print(f"\nRecent Trades (7 days): {len(history)}")
        
    finally:
        bridge.disconnect()


if __name__ == "__main__":
    main()
