"use client"

import { Bell, User, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { formatCurrency } from "@/lib/utils"

export function Header() {
  return (
    <header className="flex h-16 items-center justify-between border-b bg-card px-6">
      <div className="flex items-center gap-4">
        <div>
          <h1 className="text-lg font-semibold">Trading Dashboard</h1>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        {/* Live Prices */}
        <div className="hidden md:flex items-center gap-4 mr-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-card border">
            <span className="text-xs text-muted-foreground">XAUUSD</span>
            <span className="text-sm font-mono font-medium text-buy">2,045.32</span>
            <span className="text-xs text-buy">+0.15%</span>
          </div>
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-card border">
            <span className="text-xs text-muted-foreground">BTCUSD</span>
            <span className="text-sm font-mono font-medium text-sell">42,150.80</span>
            <span className="text-xs text-sell">-0.82%</span>
          </div>
        </div>

        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-destructive" />
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium">John Doe</p>
                <p className="text-xs text-muted-foreground">trader@example.com</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Profile</DropdownMenuItem>
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Log out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}
