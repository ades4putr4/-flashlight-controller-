import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { 
  User, 
  Account, 
  Trade, 
  TradePlan, 
  Signal, 
  LivePrice, 
  DashboardStats,
  RiskRules 
} from '@/types'

// ============================================
// AUTH STORE
// ============================================

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  setUser: (user: User | null) => void
  setAuthenticated: (value: boolean) => void
  setLoading: (value: boolean) => void
  logout: () => void
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  setUser: (user) => set({ user, isAuthenticated: !!user }),
  setAuthenticated: (value) => set({ isAuthenticated: value }),
  setLoading: (value) => set({ isLoading: value }),
  logout: () => set({ user: null, isAuthenticated: false }),
}))

// ============================================
// ACCOUNT STORE
// ============================================

interface AccountState {
  accounts: Account[]
  activeAccount: Account | null
  setAccounts: (accounts: Account[]) => void
  setActiveAccount: (account: Account | null) => void
  updateAccountBalance: (accountId: string, newBalance: number) => void
}

export const useAccountStore = create<AccountState>((set) => ({
  accounts: [],
  activeAccount: null,
  setAccounts: (accounts) => set({ accounts }),
  setActiveAccount: (account) => set({ activeAccount: account }),
  updateAccountBalance: (accountId, newBalance) => set((state) => ({
    accounts: state.accounts.map(a => 
      a.id === accountId ? { ...a, current_balance: newBalance } : a
    ),
    activeAccount: state.activeAccount?.id === accountId 
      ? { ...state.activeAccount, current_balance: newBalance }
      : state.activeAccount
  })),
}))

// ============================================
// PRICE STORE (WebSocket)
// ============================================

interface PriceState {
  prices: Record<string, LivePrice>
  isConnected: boolean
  setPrice: (price: LivePrice) => void
  setPrices: (prices: Record<string, LivePrice>) => void
  setConnected: (value: boolean) => void
  getPrice: (pair: string) => LivePrice | undefined
}

export const usePriceStore = create<PriceState>((set, get) => ({
  prices: {},
  isConnected: false,
  setPrice: (price) => set((state) => ({
    prices: { ...state.prices, [price.pair]: price }
  })),
  setPrices: (prices) => set({ prices }),
  setConnected: (value) => set({ isConnected: value }),
  getPrice: (pair) => get().prices[pair],
}))

// ============================================
// SIGNAL STORE
// ============================================

interface SignalState {
  signals: Signal[]
  activeSignals: Signal[]
  signalHistory: Signal[]
  setSignals: (signals: Signal[]) => void
  addSignal: (signal: Signal) => void
  updateSignal: (signal: Signal) => void
  setActiveSignals: (signals: Signal[]) => void
}

export const useSignalStore = create<SignalState>((set) => ({
  signals: [],
  activeSignals: [],
  signalHistory: [],
  setSignals: (signals) => set({ signals }),
  addSignal: (signal) => set((state) => ({
    signals: [signal, ...state.signals],
    activeSignals: signal.status === 'Active' 
      ? [signal, ...state.activeSignals]
      : state.activeSignals
  })),
  updateSignal: (signal) => set((state) => ({
    signals: state.signals.map(s => s.id === signal.id ? signal : s),
    activeSignals: signal.status !== 'Active'
      ? state.activeSignals.filter(s => s.id !== signal.id)
      : state.activeSignals.map(s => s.id === signal.id ? signal : s)
  })),
  setActiveSignals: (signals) => set({ activeSignals: signals }),
}))

// ============================================
// TRADE STORE
// ============================================

interface TradeState {
  trades: Trade[]
  openTrades: Trade[]
  tradeHistory: Trade[]
  setTrades: (trades: Trade[]) => void
  addTrade: (trade: Trade) => void
  updateTrade: (trade: Trade) => void
  closeTrade: (tradeId: string, updates: Partial<Trade>) => void
}

export const useTradeStore = create<TradeState>((set) => ({
  trades: [],
  openTrades: [],
  tradeHistory: [],
  setTrades: (trades) => set({ 
    trades,
    openTrades: trades.filter(t => !t.closed_at),
    tradeHistory: trades.filter(t => t.closed_at)
  }),
  addTrade: (trade) => set((state) => ({
    trades: [trade, ...state.trades],
    openTrades: [trade, ...state.openTrades]
  })),
  updateTrade: (trade) => set((state) => ({
    trades: state.trades.map(t => t.id === trade.id ? trade : t),
    openTrades: state.openTrades.map(t => t.id === trade.id ? trade : t)
  })),
  closeTrade: (tradeId, updates) => set((state) => {
    const updatedTrades = state.trades.map(t => 
      t.id === tradeId ? { ...t, ...updates, closed_at: new Date().toISOString() } : t
    )
    return {
      trades: updatedTrades,
      openTrades: state.openTrades.filter(t => t.id !== tradeId),
      tradeHistory: [...state.tradeHistory, updatedTrades.find(t => t.id === tradeId)!]
    }
  }),
}))

// ============================================
// TRADE PLAN STORE
// ============================================

interface TradePlanState {
  plans: TradePlan[]
  activePlans: TradePlan[]
  setPlans: (plans: TradePlan[]) => void
  addPlan: (plan: TradePlan) => void
  updatePlan: (plan: TradePlan) => void
  deletePlan: (planId: string) => void
}

export const useTradePlanStore = create<TradePlanState>((set) => ({
  plans: [],
  activePlans: [],
  setPlans: (plans) => set({ 
    plans,
    activePlans: plans.filter(p => p.status === 'Active' || p.status === 'Pending')
  }),
  addPlan: (plan) => set((state) => ({
    plans: [plan, ...state.plans],
    activePlans: [plan, ...state.activePlans]
  })),
  updatePlan: (plan) => set((state) => ({
    plans: state.plans.map(p => p.id === plan.id ? plan : p),
    activePlans: state.activePlans.map(p => p.id === plan.id ? plan : p)
  })),
  deletePlan: (planId) => set((state) => ({
    plans: state.plans.filter(p => p.id !== planId),
    activePlans: state.activePlans.filter(p => p.id !== planId)
  })),
}))

// ============================================
// DASHBOARD STORE
// ============================================

interface DashboardState {
  stats: DashboardStats | null
  equityHistory: { date: string; equity: number }[]
  monthlyPerformance: { month: string; profit: number; trades: number; wins: number }[]
  setupPerformance: { setup: string; trades: number; wins: number; profit: number; winRate: number }[]
  pairPerformance: { pair: string; trades: number; wins: number; profit: number; winRate: number }[]
  emotionStats: { emotion: string; trades: number; wins: number; profit: number; winRate: number }[]
  isLoading: boolean
  setStats: (stats: DashboardStats) => void
  setEquityHistory: (data: { date: string; equity: number }[]) => void
  setMonthlyPerformance: (data: { month: string; profit: number; trades: number; wins: number }[]) => void
  setSetupPerformance: (data: { setup: string; trades: number; wins: number; profit: number; winRate: number }[]) => void
  setPairPerformance: (data: { pair: string; trades: number; wins: number; profit: number; winRate: number }[]) => void
  setEmotionStats: (data: { emotion: string; trades: number; wins: number; profit: number; winRate: number }[]) => void
  setLoading: (value: boolean) => void
}

export const useDashboardStore = create<DashboardState>((set) => ({
  stats: null,
  equityHistory: [],
  monthlyPerformance: [],
  setupPerformance: [],
  pairPerformance: [],
  emotionStats: [],
  isLoading: false,
  setStats: (stats) => set({ stats }),
  setEquityHistory: (data) => set({ equityHistory: data }),
  setMonthlyPerformance: (data) => set({ monthlyPerformance: data }),
  setSetupPerformance: (data) => set({ setupPerformance: data }),
  setPairPerformance: (data) => set({ pairPerformance: data }),
  setEmotionStats: (data) => set({ emotionStats: data }),
  setLoading: (value) => set({ isLoading: value }),
}))

// ============================================
// RISK STORE
// ============================================

interface RiskState {
  riskRules: RiskRules | null
  dailyLoss: number
  weeklyLoss: number
  currentDrawdown: number
  isTradingBlocked: boolean
  blockReason?: string
  setRiskRules: (rules: RiskRules) => void
  updateDailyLoss: (loss: number) => void
  updateWeeklyLoss: (loss: number) => void
  setTradingBlocked: (blocked: boolean, reason?: string) => void
}

export const useRiskStore = create<RiskState>((set) => ({
  riskRules: null,
  dailyLoss: 0,
  weeklyLoss: 0,
  currentDrawdown: 0,
  isTradingBlocked: false,
  setRiskRules: (rules) => set({ riskRules: rules }),
  updateDailyLoss: (loss) => set({ dailyLoss: loss }),
  updateWeeklyLoss: (loss) => set({ weeklyLoss: loss }),
  setTradingBlocked: (blocked, reason) => set({ isTradingBlocked: blocked, blockReason: reason }),
}))

// ============================================
// UI STORE
// ============================================

interface UIState {
  sidebarOpen: boolean
  theme: 'dark' | 'light'
  notifications: { id: string; title: string; message: string; type: 'info' | 'success' | 'warning' | 'error' }[]
  toggleSidebar: () => void
  setTheme: (theme: 'dark' | 'light') => void
  addNotification: (notification: Omit<UIState['notifications'][0], 'id'>) => void
  removeNotification: (id: string) => void
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  theme: 'dark',
  notifications: [],
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setTheme: (theme) => set({ theme }),
  addNotification: (notification) => set((state) => ({
    notifications: [
      { ...notification, id: Math.random().toString(36).substr(2, 9) },
      ...state.notifications
    ]
  })),
  removeNotification: (id) => set((state) => ({
    notifications: state.notifications.filter(n => n.id !== id)
  })),
}))
