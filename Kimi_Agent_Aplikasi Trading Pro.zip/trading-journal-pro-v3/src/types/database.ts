export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          timezone: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          timezone?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          timezone?: string
          created_at?: string
          updated_at?: string
        }
      }
      accounts: {
        Row: {
          id: string
          user_id: string
          name: string
          account_type: 'Personal' | 'Funded' | 'Prop'
          broker: string | null
          account_number: string | null
          initial_balance: number
          current_balance: number
          equity: number
          leverage: number
          currency: string
          risk_per_trade: number
          max_daily_loss: number
          max_weekly_loss: number
          max_trailing_drawdown: number
          max_open_trades: number
          profit_target: number | null
          time_limit_days: number | null
          is_active: boolean
          is_funded: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          account_type: 'Personal' | 'Funded' | 'Prop'
          broker?: string | null
          account_number?: string | null
          initial_balance?: number
          current_balance?: number
          equity?: number
          leverage?: number
          currency?: string
          risk_per_trade?: number
          max_daily_loss?: number
          max_weekly_loss?: number
          max_trailing_drawdown?: number
          max_open_trades?: number
          profit_target?: number | null
          time_limit_days?: number | null
          is_active?: boolean
          is_funded?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          account_type?: 'Personal' | 'Funded' | 'Prop'
          broker?: string | null
          account_number?: string | null
          initial_balance?: number
          current_balance?: number
          equity?: number
          leverage?: number
          currency?: string
          risk_per_trade?: number
          max_daily_loss?: number
          max_weekly_loss?: number
          max_trailing_drawdown?: number
          max_open_trades?: number
          profit_target?: number | null
          time_limit_days?: number | null
          is_active?: boolean
          is_funded?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      trades: {
        Row: {
          id: string
          user_id: string
          account_id: string
          plan_id: string | null
          pair: string
          timeframe: string
          setup_type: string
          direction: 'Buy' | 'Sell'
          entry_price: number
          exit_price: number | null
          stop_loss: number
          take_profit_1: number
          lot_size: number
          risk_percent: number
          rr_planned: number | null
          rr_achieved: number | null
          result: 'Win' | 'Loss' | 'BreakEven' | null
          profit_loss: number | null
          profit_loss_pips: number | null
          profit_loss_percent: number | null
          opened_at: string
          closed_at: string | null
          duration_minutes: number | null
          emotion: 'Calm' | 'FOMO' | 'Revenge' | 'Overconfidence' | 'Fear' | 'Hesitation' | null
          rules_followed: boolean
          grade: 'A' | 'B' | 'C' | 'D' | null
          grade_score: number | null
          mistake_tags: string[]
          evaluation_notes: string | null
          lessons_learned: string | null
          screenshot_before: string | null
          screenshot_after: string | null
          signal_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          account_id: string
          plan_id?: string | null
          pair: string
          timeframe: string
          setup_type: string
          direction: 'Buy' | 'Sell'
          entry_price: number
          exit_price?: number | null
          stop_loss: number
          take_profit_1: number
          lot_size: number
          risk_percent: number
          rr_planned?: number | null
          rr_achieved?: number | null
          result?: 'Win' | 'Loss' | 'BreakEven' | null
          profit_loss?: number | null
          profit_loss_pips?: number | null
          profit_loss_percent?: number | null
          opened_at?: string
          closed_at?: string | null
          duration_minutes?: number | null
          emotion?: 'Calm' | 'FOMO' | 'Revenge' | 'Overconfidence' | 'Fear' | 'Hesitation' | null
          rules_followed?: boolean
          grade?: 'A' | 'B' | 'C' | 'D' | null
          grade_score?: number | null
          mistake_tags?: string[]
          evaluation_notes?: string | null
          lessons_learned?: string | null
          screenshot_before?: string | null
          screenshot_after?: string | null
          signal_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          account_id?: string
          plan_id?: string | null
          pair?: string
          timeframe?: string
          setup_type?: string
          direction?: 'Buy' | 'Sell'
          entry_price?: number
          exit_price?: number | null
          stop_loss?: number
          take_profit_1?: number
          lot_size?: number
          risk_percent?: number
          rr_planned?: number | null
          rr_achieved?: number | null
          result?: 'Win' | 'Loss' | 'BreakEven' | null
          profit_loss?: number | null
          profit_loss_pips?: number | null
          profit_loss_percent?: number | null
          opened_at?: string
          closed_at?: string | null
          duration_minutes?: number | null
          emotion?: 'Calm' | 'FOMO' | 'Revenge' | 'Overconfidence' | 'Fear' | 'Hesitation' | null
          rules_followed?: boolean
          grade?: 'A' | 'B' | 'C' | 'D' | null
          grade_score?: number | null
          mistake_tags?: string[]
          evaluation_notes?: string | null
          lessons_learned?: string | null
          screenshot_before?: string | null
          screenshot_after?: string | null
          signal_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      signals: {
        Row: {
          id: string
          pair: string
          timeframe: string
          direction: 'Buy' | 'Sell'
          entry_price: number
          stop_loss: number
          take_profit_1: number
          take_profit_2: number | null
          take_profit_3: number | null
          rr_ratio: number
          setup_quality: number
          signal_strength: number
          market_condition: string | null
          trend_direction: string | null
          volatility_state: string | null
          confluences: string[]
          spread_pips: number | null
          adr_percent: number | null
          session: string | null
          status: 'Active' | 'Triggered' | 'Hit TP1' | 'Hit TP2' | 'Hit TP3' | 'Hit SL' | 'Expired' | 'Cancelled'
          result: 'Win' | 'Loss' | 'BreakEven' | null
          pips_gained: number | null
          created_at: string
          triggered_at: string | null
          closed_at: string | null
          expires_at: string | null
          candle_close_time: string | null
        }
        Insert: {
          id?: string
          pair: string
          timeframe: string
          direction: 'Buy' | 'Sell'
          entry_price: number
          stop_loss: number
          take_profit_1: number
          take_profit_2?: number | null
          take_profit_3?: number | null
          rr_ratio: number
          setup_quality: number
          signal_strength: number
          market_condition?: string | null
          trend_direction?: string | null
          volatility_state?: string | null
          confluences?: string[]
          spread_pips?: number | null
          adr_percent?: number | null
          session?: string | null
          status?: 'Active' | 'Triggered' | 'Hit TP1' | 'Hit TP2' | 'Hit TP3' | 'Hit SL' | 'Expired' | 'Cancelled'
          result?: 'Win' | 'Loss' | 'BreakEven' | null
          pips_gained?: number | null
          created_at?: string
          triggered_at?: string | null
          closed_at?: string | null
          expires_at?: string | null
          candle_close_time?: string | null
        }
        Update: {
          id?: string
          pair?: string
          timeframe?: string
          direction?: 'Buy' | 'Sell'
          entry_price?: number
          stop_loss?: number
          take_profit_1?: number
          take_profit_2?: number | null
          take_profit_3?: number | null
          rr_ratio?: number
          setup_quality?: number
          signal_strength?: number
          market_condition?: string | null
          trend_direction?: string | null
          volatility_state?: string | null
          confluences?: string[]
          spread_pips?: number | null
          adr_percent?: number | null
          session?: string | null
          status?: 'Active' | 'Triggered' | 'Hit TP1' | 'Hit TP2' | 'Hit TP3' | 'Hit SL' | 'Expired' | 'Cancelled'
          result?: 'Win' | 'Loss' | 'BreakEven' | null
          pips_gained?: number | null
          created_at?: string
          triggered_at?: string | null
          closed_at?: string | null
          expires_at?: string | null
          candle_close_time?: string | null
        }
      }
      live_prices: {
        Row: {
          pair: string
          bid: number
          ask: number
          spread: number
          change: number
          change_percent: number
          high_24h: number
          low_24h: number
          adr: number
          adr_percent: number
          volume: number
          timestamp: string
        }
        Insert: {
          pair: string
          bid: number
          ask: number
          spread: number
          change: number
          change_percent: number
          high_24h: number
          low_24h: number
          adr: number
          adr_percent: number
          volume: number
          timestamp?: string
        }
        Update: {
          pair?: string
          bid?: number
          ask?: number
          spread?: number
          change?: number
          change_percent?: number
          high_24h?: number
          low_24h?: number
          adr?: number
          adr_percent?: number
          volume?: number
          timestamp?: string
        }
      }
    }
  }
}
