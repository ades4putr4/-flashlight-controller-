// ============================================
// USER TYPES
// ============================================

export interface User {
  id: string
  email: string
  full_name?: string
  avatar_url?: string
  timezone: string
  created_at: string
}

// ============================================
// ACCOUNT TYPES
// ============================================

export type AccountType = 'Personal' | 'Funded' | 'Prop'

export interface Account {
  id: string
  user_id: string
  name: string
  account_type: AccountType
  broker?: string
  account_number?: string
  
  // Capital
  initial_balance: number
  current_balance: number
  equity: number
  leverage: number
  currency: string
  
  // Risk Settings
  risk_per_trade: number
  max_daily_loss: number
  max_weekly_loss: number
  max_trailing_drawdown: number
  max_open_trades: number
  
  // Prop Firm
  profit_target?: number
  time_limit_days?: number
  is_active: boolean
  is_funded: boolean
  
  created_at: string
  updated_at: string
}

// ============================================
// TRADE PLAN TYPES
// ============================================

export type TradeDirection = 'Buy' | 'Sell'
export type MarketBias = 'Bullish' | 'Bearish' | 'Neutral'
export type NewsImpact = 'None' | 'Low' | 'Medium' | 'High'
export type PlanStatus = 'Pending' | 'Active' | 'Executed' | 'Cancelled'

export interface TradePlan {
  id: string
  user_id: string
  account_id: string
  
  pair: string
  timeframe: string
  setup_type: string
  direction: TradeDirection
  
  entry_price: number
  stop_loss: number
  take_profit_1: number
  take_profit_2?: number
  take_profit_3?: number
  
  risk_percent: number
  lot_size: number
  rr_ratio: number
  potential_profit?: number
  potential_loss?: number
  
  setup_quality: number
  market_bias?: MarketBias
  news_impact: NewsImpact
  
  adr_percent?: number
  spread_pips?: number
  is_valid_rr: boolean
  is_within_daily_loss: boolean
  
  screenshot_before?: string
  checklist: string[]
  analysis_notes?: string
  
  status: PlanStatus
  
  created_at: string
  updated_at: string
  planned_at?: string
}

// ============================================
// TRADE TYPES
// ============================================

export type TradeResult = 'Win' | 'Loss' | 'BreakEven'
export type EmotionType = 'Calm' | 'FOMO' | 'Revenge' | 'Overconfidence' | 'Fear' | 'Hesitation'
export type TradeGrade = 'A' | 'B' | 'C' | 'D'

export interface Trade {
  id: string
  user_id: string
  account_id: string
  plan_id?: string
  
  pair: string
  timeframe: string
  setup_type: string
  direction: TradeDirection
  
  entry_price: number
  exit_price?: number
  stop_loss: number
  take_profit_1: number
  
  lot_size: number
  risk_percent: number
  rr_planned?: number
  rr_achieved?: number
  
  result?: TradeResult
  profit_loss?: number
  profit_loss_pips?: number
  profit_loss_percent?: number
  
  opened_at: string
  closed_at?: string
  duration_minutes?: number
  
  emotion?: EmotionType
  rules_followed: boolean
  
  grade?: TradeGrade
  grade_score?: number
  
  mistake_tags: string[]
  evaluation_notes?: string
  lessons_learned?: string
  
  screenshot_before?: string
  screenshot_after?: string
  
  signal_id?: string
  
  created_at: string
  updated_at: string
}

// ============================================
// SIGNAL TYPES
// ============================================

export type SignalStatus = 'Active' | 'Triggered' | 'Hit TP1' | 'Hit TP2' | 'Hit TP3' | 'Hit SL' | 'Expired' | 'Cancelled'
export type MarketCondition = 'Trending' | 'Ranging' | 'Volatile' | 'Low Liquidity'

export interface Signal {
  id: string
  pair: string
  timeframe: string
  direction: TradeDirection
  
  entry_price: number
  stop_loss: number
  take_profit_1: number
  take_profit_2?: number
  take_profit_3?: number
  
  rr_ratio: number
  setup_quality: number
  signal_strength: number
  
  market_condition?: MarketCondition
  trend_direction?: string
  volatility_state?: string
  
  confluences: string[]
  
  spread_pips?: number
  adr_percent?: number
  session?: string
  
  status: SignalStatus
  result?: TradeResult
  pips_gained?: number
  
  created_at: string
  triggered_at?: string
  closed_at?: string
  expires_at?: string
  candle_close_time?: string
}

// ============================================
// LIVE PRICE TYPES
// ============================================

export interface LivePrice {
  pair: string
  bid: number
  ask: number
  spread: number
  change: number
  change_percent: number
  high_24h: number
  low_24h: number
  adr: number
  adr_percent: number
  volume: number
  timestamp: string
}

// ============================================
// RISK RULES TYPES
// ============================================

export interface RiskRules {
  id: string
  user_id: string
  account_id: string
  
  max_risk_per_trade: number
  max_daily_loss: number
  max_weekly_loss: number
  max_monthly_loss: number
  max_trailing_drawdown: number
  max_open_trades: number
  
  daily_loss_today: number
  weekly_loss_this_week: number
  monthly_loss_this_month: number
  current_drawdown: number
  
  trading_blocked: boolean
  block_reason?: string
  blocked_until?: string
  
  alert_on_daily_70_percent: boolean
  alert_on_daily_90_percent: boolean
  alert_on_weekly_70_percent: boolean
  
  created_at: string
  updated_at: string
}

// ============================================
// DASHBOARD STATS TYPES
// ============================================

export interface DashboardStats {
  currentBalance: number
  totalProfitLoss: number
  totalProfitLossPercent: number
  winRate: number
  profitFactor: number
  averageRR: number
  maxDrawdown: number
  riskPerTrade: number
  totalTrades: number
  winningTrades: number
  losingTrades: number
  breakEvenTrades: number
  openTrades: number
  expectancy: number
}

export interface MonthlyPerformance {
  month: string
  profit: number
  trades: number
  wins: number
}

export interface SetupPerformance {
  setup: string
  trades: number
  wins: number
  profit: number
  winRate: number
}

export interface PairPerformance {
  pair: string
  trades: number
  wins: number
  profit: number
  winRate: number
}

export interface EmotionStats {
  emotion: EmotionType
  trades: number
  wins: number
  profit: number
  winRate: number
}

export interface EquityPoint {
  date: string
  equity: number
}

// ============================================
// SIGNAL STATS TYPES
// ============================================

export interface SignalStats {
  pair: string
  timeframe: string
  totalSignals: number
  winningSignals: number
  losingSignals: number
  accuracyRate: number
  avgPipsPerSignal: number
}

// ============================================
// MM SIMULATION TYPES
// ============================================

export type MMStrategyType = 'Fixed Risk' | 'Compounding' | 'Martingale' | 'Anti-Martingale' | 'Kelly Criterion'

export interface MMSimulation {
  id: string
  user_id: string
  name: string
  strategy_type: MMStrategyType
  
  initial_capital: number
  risk_per_trade: number
  win_rate: number
  avg_rr: number
  num_trades: number
  
  final_capital?: number
  total_return?: number
  max_drawdown?: number
  risk_of_ruin?: number
  simulation_data?: any
  
  created_at: string
}

// ============================================
// TRADING RULES TYPES
// ============================================

export interface TradingRule {
  id: string
  user_id: string
  rule: string
  category: string
  priority: number
  is_active: boolean
  created_at: string
  updated_at: string
}

// ============================================
// REVIEW TYPES
// ============================================

export interface WeeklyReview {
  id: string
  user_id: string
  account_id: string
  week_start: string
  week_end: string
  starting_balance: number
  ending_balance: number
  total_trades: number
  winning_trades: number
  losing_trades: number
  what_went_well?: string
  what_to_improve?: string
  discipline_rating?: number
  goals_for_next_week?: string
  created_at: string
  updated_at: string
}

export interface MonthlyReflection {
  id: string
  user_id: string
  account_id: string
  month: string
  starting_balance: number
  ending_balance: number
  total_profit_loss: number
  return_percent: number
  best_trade?: string
  worst_trade?: string
  emotional_patterns?: string
  strategy_adjustments?: string
  goals_progress?: string
  created_at: string
  updated_at: string
}

// ============================================
// WEBSOCKET TYPES
// ============================================

export interface WSPriceUpdate {
  pair: string
  bid: number
  ask: number
  spread: number
  timestamp: number
}

export interface WSSignalUpdate {
  type: 'NEW_SIGNAL' | 'SIGNAL_UPDATE' | 'SIGNAL_CLOSE'
  signal: Signal
}

// ============================================
// CONSTANTS
// ============================================

export const FOREX_PAIRS = [
  'EURUSD', 'GBPUSD', 'USDJPY', 'USDCHF', 'AUDUSD', 'NZDUSD', 'USDCAD',
  'EURGBP', 'EURJPY', 'GBPJPY', 'AUDJPY', 'CHFJPY', 'EURCHF', 'GBPCHF',
  'XAUUSD', 'XAGUSD', 'US30', 'NAS100', 'SPX500', 'BTCUSD', 'ETHUSD'
] as const

export const TIMEFRAMES = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1', 'MN'] as const

export const SETUP_TYPES = [
  'Supply Demand', 'Support Resistance', 'Trendline', 'Fibonacci',
  'Breakout', 'Pullback', 'Engulfing', 'Pin Bar', 'Inside Bar',
  'Morning Star', 'Evening Star', 'Head Shoulders', 'Double Top',
  'Double Bottom', 'Flag Pattern', 'BOS', 'CHoCH', 'FVG', 'Liquidity Grab'
] as const

export const EMOTIONS: EmotionType[] = ['Calm', 'FOMO', 'Revenge', 'Overconfidence', 'Fear', 'Hesitation']

export const MISTAKE_TAGS = [
  'Entered too early',
  'Entered too late',
  'Moved stop loss',
  'Closed early',
  'Overtraded',
  'Ignored plan',
  'Emotional decision',
  'Poor risk management',
  'No stop loss',
  'Wrong position size'
] as const

export const PRE_TRADE_CHECKLIST = [
  'Trend analysis completed',
  'Key levels identified',
  'Risk/Reward ratio >= 1:2',
  'Position size calculated',
  'News check completed',
  'Emotion check - calm & focused',
  'Trading plan written',
  'Stop loss set',
  'Confluences confirmed',
  'Spread acceptable'
] as const
