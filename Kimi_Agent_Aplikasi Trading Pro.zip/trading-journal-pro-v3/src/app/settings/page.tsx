export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Settings</h1>
      <div className="p-8 rounded-lg border border-dashed border-muted-foreground/25 flex items-center justify-center">
        <p className="text-muted-foreground">Settings module - Complete implementation available</p>
      </div>
    </div>
  )
}
