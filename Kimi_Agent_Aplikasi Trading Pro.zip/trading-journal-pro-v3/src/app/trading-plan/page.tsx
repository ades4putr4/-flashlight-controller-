"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { calculateLotSize, calculateRR, formatCurrency } from "@/lib/utils"
import { AlertTriangle, Calculator, Camera, TrendingUp, TrendingDown } from "lucide-react"

const forexPairs = [
  "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "NZDUSD", "USDCAD",
  "EURGBP", "EURJPY", "GBPJPY", "AUDJPY", "CHFJPY", "EURCHF", "GBPCHF",
  "XAUUSD", "XAGUSD", "US30", "NAS100", "SPX500", "BTCUSD", "ETHUSD"
]

const timeframes = ["M1", "M5", "M15", "M30", "H1", "H4", "D1", "W1", "MN"]

const setupTypes = [
  "Supply Demand", "Support Resistance", "Trendline", "Fibonacci",
  "Breakout", "Pullback", "Engulfing", "Pin Bar", "Inside Bar",
  "Morning Star", "Evening Star", "BOS", "CHoCH", "FVG", "Liquidity Grab"
]

const checklistItems = [
  "Trend analysis completed",
  "Key levels identified",
  "Risk/Reward ratio >= 1:2",
  "Position size calculated",
  "News check completed",
  "Emotion check - calm & focused",
  "Trading plan written",
  "Stop loss set",
  "Confluences confirmed",
  "Spread acceptable"
]

export default function TradingPlanPage() {
  const [formData, setFormData] = useState({
    pair: "",
    timeframe: "M15",
    setupType: "",
    direction: "Buy",
    entryPrice: "",
    stopLoss: "",
    takeProfit1: "",
    takeProfit2: "",
    takeProfit3: "",
    balance: 10000,
    riskPercent: 1,
    lotSize: 0,
    rr: 0,
    setupQuality: 70,
    newsImpact: "None",
    notes: "",
    checklist: [] as string[],
  })

  const [warnings, setWarnings] = useState<string[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Trading Plan:", formData)
  }

  const isBuy = formData.direction === "Buy"

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Trading Plan</h1>
        <Button variant="outline">
          <Camera className="mr-2 h-4 w-4" />
          Upload Screenshot
        </Button>
      </div>

      {warnings.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <ul className="list-disc list-inside">
              {warnings.map((warning, i) => (
                <li key={i}>{warning}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Trade Details */}
        <Card>
          <CardHeader>
            <CardTitle>Trade Details</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label>Pair</Label>
              <Select value={formData.pair} onValueChange={(v) => setFormData({...formData, pair: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select pair" />
                </SelectTrigger>
                <SelectContent>
                  {forexPairs.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Timeframe</Label>
              <Select value={formData.timeframe} onValueChange={(v) => setFormData({...formData, timeframe: v})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeframes.map(tf => <SelectItem key={tf} value={tf}>{tf}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Setup Type</Label>
              <Select value={formData.setupType} onValueChange={(v) => setFormData({...formData, setupType: v})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select setup" />
                </SelectTrigger>
                <SelectContent>
                  {setupTypes.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Direction</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant={isBuy ? "buy" : "outline"}
                  className="flex-1"
                  onClick={() => setFormData({...formData, direction: "Buy"})}
                >
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Buy
                </Button>
                <Button
                  type="button"
                  variant={!isBuy ? "sell" : "outline"}
                  className="flex-1"
                  onClick={() => setFormData({...formData, direction: "Sell"})}
                >
                  <TrendingDown className="mr-2 h-4 w-4" />
                  Sell
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Price Levels */}
        <Card>
          <CardHeader>
            <CardTitle>Price Levels</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label>Entry Price</Label>
              <Input type="number" step="0.00001" placeholder="1.08500" />
            </div>
            <div className="space-y-2">
              <Label>Stop Loss</Label>
              <Input type="number" step="0.00001" placeholder="1.08000" />
            </div>
            <div className="space-y-2">
              <Label>Take Profit 1</Label>
              <Input type="number" step="0.00001" placeholder="1.09500" />
            </div>
            <div className="space-y-2">
              <Label>R:R Ratio</Label>
              <div className="flex h-10 items-center rounded-md border border-input bg-muted px-3">
                <span className="font-medium text-profit">1:2.5</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Risk Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Risk Management
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label>Account Balance</Label>
              <Input type="number" value={formData.balance} readOnly />
            </div>
            <div className="space-y-2">
              <Label>Risk %</Label>
              <Input type="number" step="0.1" min="0.1" max="5" value={formData.riskPercent} />
            </div>
            <div className="space-y-2">
              <Label>Risk Amount</Label>
              <div className="flex h-10 items-center rounded-md border border-input bg-muted px-3">
                <span className="font-medium">{formatCurrency(formData.balance * (formData.riskPercent / 100))}</span>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Lot Size (Auto)</Label>
              <div className="flex h-10 items-center rounded-md border border-input bg-muted px-3">
                <span className="font-medium text-primary">0.25</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Checklist */}
        <Card>
          <CardHeader>
            <CardTitle>Pre-Trade Checklist</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2">
              {checklistItems.map((item) => (
                <div key={item} className="flex items-center space-x-2">
                  <Checkbox id={item} />
                  <Label htmlFor={item} className="text-sm font-normal cursor-pointer">
                    {item}
                  </Label>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-4">
          <Button type="submit" size="lg" className="flex-1">
            Save Trading Plan
          </Button>
          <Button type="button" variant="outline" size="lg">
            Save as Template
          </Button>
        </div>
      </form>
    </div>
  )
}
