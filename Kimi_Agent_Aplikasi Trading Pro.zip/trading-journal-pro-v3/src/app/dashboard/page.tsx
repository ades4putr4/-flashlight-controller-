"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Percent, 
  BarChart3, 
  Activity,
  Wallet,
  Zap,
  AlertTriangle,
  Clock
} from "lucide-react"
import { formatCurrency, formatPercentage, formatNumber } from "@/lib/utils"
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell
} from "recharts"

// Mock data
const equityData = [
  { date: "Jan", equity: 10000 },
  { date: "Feb", equity: 10800 },
  { date: "Mar", equity: 10500 },
  { date: "Apr", equity: 11500 },
  { date: "May", equity: 11200 },
  { date: "Jun", equity: 12500 },
]

const dailyPnL = [
  { day: "Mon", profit: 150 },
  { day: "Tue", profit: -80 },
  { day: "Wed", profit: 220 },
  { day: "Thu", profit: 45 },
  { day: "Fri", profit: -120 },
]

const setupPerformance = [
  { name: "BOS/CHoCH", value: 35, profit: 1850 },
  { name: "Supply/Demand", value: 25, profit: 1200 },
  { name: "FVG", value: 20, profit: 950 },
  { name: "Liquidity Grab", value: 15, profit: 420 },
  { name: "Other", value: 5, profit: 150 },
]

const stats = {
  currentBalance: 12500,
  totalProfitLoss: 2500,
  totalProfitLossPercent: 25,
  winRate: 68.5,
  profitFactor: 2.1,
  averageRR: 2.4,
  maxDrawdown: 6.8,
  riskPerTrade: 1,
  totalTrades: 145,
  winningTrades: 99,
  losingTrades: 43,
  breakEvenTrades: 3,
  openTrades: 2,
}

const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6']

export default function DashboardPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, Trader</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Clock className="mr-2 h-4 w-4" />
            Asian Session
          </Button>
          <Badge variant="profit" className="text-sm">
            <Zap className="mr-1 h-3 w-3" />
            Live
          </Badge>
        </div>
      </div>

      {/* Risk Alert */}
      <div className="flex items-center gap-3 p-4 rounded-lg bg-warning/10 border border-warning/20">
        <AlertTriangle className="h-5 w-5 text-warning" />
        <div className="flex-1">
          <p className="text-sm font-medium">Daily Loss: 67% of limit</p>
          <Progress value={67} className="h-2 mt-1" />
        </div>
        <span className="text-sm text-warning font-medium">$201 / $300</span>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(stats.currentBalance)}</div>
            <p className="text-xs text-muted-foreground">
              <span className={stats.totalProfitLoss >= 0 ? "text-profit" : "text-loss"}>
                {stats.totalProfitLoss >= 0 ? "+" : ""}{formatCurrency(stats.totalProfitLoss)}
              </span>
              {" "}({formatPercentage(stats.totalProfitLossPercent)})
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.winRate}%</div>
            <p className="text-xs text-muted-foreground">
              {stats.winningTrades}W / {stats.losingTrades}L / {stats.breakEvenTrades}BE
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.profitFactor}</div>
            <p className="text-xs text-muted-foreground">
              Average RR: {stats.averageRR}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Max Drawdown</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-loss">{stats.maxDrawdown}%</div>
            <p className="text-xs text-muted-foreground">
              Open trades: {stats.openTrades}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Equity Curve</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={equityData}>
                <defs>
                  <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="date" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="equity" 
                  stroke="#22c55e" 
                  fillOpacity={1} 
                  fill="url(#colorEquity)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Daily P&L</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={dailyPnL}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis dataKey="day" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                />
                <Bar dataKey="profit" fill="#22c55e">
                  {dailyPnL.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.profit >= 0 ? '#22c55e' : '#ef4444'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Setup Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={setupPerformance}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {setupPerformance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button className="w-full" variant="default">
              <TrendingUp className="mr-2 h-4 w-4" />
              New Trade Plan
            </Button>
            <Button className="w-full" variant="outline">
              <Zap className="mr-2 h-4 w-4" />
              View Signals
            </Button>
            <Button className="w-full" variant="outline">
              <BarChart3 className="mr-2 h-4 w-4" />
              Analytics
            </Button>
            <Button className="w-full" variant="outline">
              <Activity className="mr-2 h-4 w-4" />
              Risk Management
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
