"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { 
  TrendingUp, 
  TrendingDown, 
  Zap, 
  Target, 
  Clock,
  Activity,
  Shield,
  AlertTriangle,
  CheckCircle2
} from "lucide-react"
import { formatPrice, formatCurrency } from "@/lib/utils"

// Mock signal data
const mockSignals = [
  {
    id: "1",
    pair: "XAUUSD",
    direction: "Buy" as const,
    entry: 2045.32,
    stopLoss: 2038.50,
    takeProfit1: 2055.00,
    takeProfit2: 2062.00,
    rr: 2.4,
    setupQuality: 85,
    signalStrength: 78,
    spread: 0.18,
    adrPercent: 65,
    confluences: ["BOS", "FVG", "Liquidity Grab"],
    marketCondition: "Trending",
    timeRemaining: 8,
  },
  {
    id: "2",
    pair: "BTCUSD",
    direction: "Sell" as const,
    entry: 42150.80,
    stopLoss: 42800.00,
    takeProfit1: 41000.00,
    takeProfit2: 40500.00,
    rr: 2.1,
    setupQuality: 72,
    signalStrength: 65,
    spread: 12.5,
    adrPercent: 78,
    confluences: ["CHoCH", "Supply Zone"],
    marketCondition: "Ranging",
    timeRemaining: 12,
  },
]

function SignalCard({ signal }: { signal: typeof mockSignals[0] }) {
  const isBuy = signal.direction === "Buy"
  
  return (
    <Card className={`relative overflow-hidden ${isBuy ? 'border-buy/30' : 'border-sell/30'}`}>
      <div className={`absolute top-0 left-0 w-1 h-full ${isBuy ? 'bg-buy' : 'bg-sell'}`} />
      
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Badge variant={isBuy ? "buy" : "sell"} className="text-sm px-3 py-1">
              {isBuy ? <TrendingUp className="mr-1 h-4 w-4" /> : <TrendingDown className="mr-1 h-4 w-4" />}
              {signal.direction}
            </Badge>
            <span className="text-xl font-bold">{signal.pair}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{signal.timeRemaining}m</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Price Levels */}
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center p-3 rounded-lg bg-muted">
            <p className="text-xs text-muted-foreground mb-1">Entry</p>
            <p className="font-mono font-medium">{formatPrice(signal.entry, signal.pair)}</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-loss/10">
            <p className="text-xs text-muted-foreground mb-1">SL</p>
            <p className="font-mono font-medium text-loss">{formatPrice(signal.stopLoss, signal.pair)}</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-profit/10">
            <p className="text-xs text-muted-foreground mb-1">TP1</p>
            <p className="font-mono font-medium text-profit">{formatPrice(signal.takeProfit1, signal.pair)}</p>
          </div>
          <div className="text-center p-3 rounded-lg bg-profit/10">
            <p className="text-xs text-muted-foreground mb-1">TP2</p>
            <p className="font-mono font-medium text-profit">{formatPrice(signal.takeProfit2, signal.pair)}</p>
          </div>
        </div>
        
        {/* Signal Metrics */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">R:R Ratio</span>
              <span className="text-sm font-medium">1:{signal.rr}</span>
            </div>
            <Progress value={(signal.rr / 3) * 100} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">Setup Quality</span>
              <span className="text-sm font-medium">{signal.setupQuality}%</span>
            </div>
            <Progress value={signal.setupQuality} className="h-2" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-muted-foreground">Signal Strength</span>
              <span className="text-sm font-medium">{signal.signalStrength}%</span>
            </div>
            <Progress value={signal.signalStrength} className="h-2" />
          </div>
        </div>
        
        {/* Confluences */}
        <div className="flex flex-wrap gap-2">
          {signal.confluences.map((conf) => (
            <Badge key={conf} variant="secondary" className="text-xs">
              <CheckCircle2 className="mr-1 h-3 w-3" />
              {conf}
            </Badge>
          ))}
        </div>
        
        {/* Market Info */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <span className="text-muted-foreground">Spread: {signal.spread} pips</span>
            <span className="text-muted-foreground">ADR: {signal.adrPercent}%</span>
          </div>
          <Badge variant="outline">{signal.marketCondition}</Badge>
        </div>
        
        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button className="flex-1" variant={isBuy ? "buy" : "sell"}>
            <Target className="mr-2 h-4 w-4" />
            Create Trade Plan
          </Button>
          <Button variant="outline">
            <Activity className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default function SignalsPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Live Signals</h1>
          <p className="text-muted-foreground">Real-time M15 signals for XAUUSD & BTCUSD</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="profit" className="text-sm">
            <Zap className="mr-1 h-3 w-3" />
            Live Feed
          </Badge>
        </div>
      </div>

      {/* Market Status */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="h-4 w-4" />
              XAUUSD Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-buy animate-pulse" />
              <span className="text-sm font-medium">Active</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">2,045.32 (+0.15%)</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Activity className="h-4 w-4" />
              BTCUSD Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-sell animate-pulse" />
              <span className="text-sm font-medium">Active</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">42,150.80 (-0.82%)</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Signal Accuracy
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-profit">72.5%</div>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Risk Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-profit" />
              <span className="text-sm font-medium">Passing</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">All parameters OK</p>
          </CardContent>
        </Card>
      </div>

      {/* Active Signals */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Active Signals</h2>
        {mockSignals.map((signal) => (
          <SignalCard key={signal.id} signal={signal} />
        ))}
      </div>

      {/* Signal History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Signal History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[
              { pair: "XAUUSD", direction: "Buy", result: "Win", pips: 45, time: "2h ago" },
              { pair: "BTCUSD", direction: "Sell", result: "Loss", pips: -28, time: "5h ago" },
              { pair: "XAUUSD", direction: "Buy", result: "Win", pips: 62, time: "1d ago" },
            ].map((trade, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  <Badge variant={trade.direction === "Buy" ? "buy" : "sell"}>
                    {trade.direction}
                  </Badge>
                  <span className="font-medium">{trade.pair}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`text-sm font-medium ${trade.result === "Win" ? "text-profit" : "text-loss"}`}>
                    {trade.result} ({trade.pips > 0 ? "+" : ""}{trade.pips} pips)
                  </span>
                  <span className="text-xs text-muted-foreground">{trade.time}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
