import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatCurrency(value: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(value)
}

export function formatPercentage(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`
}

export function formatNumber(value: number, decimals = 2): string {
  return value.toFixed(decimals)
}

export function formatPips(value: number): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(1)} pips`
}

export function formatPrice(value: number, pair?: string): string {
  const isJpy = pair?.includes('JPY')
  const isGold = pair?.includes('XAU') || pair?.includes('GOLD')
  const decimals = isJpy ? 3 : isGold ? 2 : 5
  return value.toFixed(decimals)
}

// ============================================
// RISK CALCULATOR FUNCTIONS
// ============================================

export interface LotSizeParams {
  balance: number
  riskPercent: number
  entryPrice: number
  stopLoss: number
  pair: string
  leverage?: number
}

export function calculateLotSize(params: LotSizeParams): number {
  const { balance, riskPercent, entryPrice, stopLoss, pair } = params
  
  const riskAmount = balance * (riskPercent / 100)
  const slDistance = Math.abs(entryPrice - stopLoss)
  
  if (slDistance === 0) return 0
  
  // Pip value calculation
  const isJpy = pair.includes('JPY')
  const isGold = pair.includes('XAU') || pair.includes('GOLD')
  const isSilver = pair.includes('XAG') || pair.includes('SILVER')
  
  let pipValue: number
  let pipSize: number
  
  if (isGold) {
    pipValue = 10 // $10 per pip for 1 lot XAUUSD
    pipSize = 0.01
  } else if (isSilver) {
    pipValue = 10
    pipSize = 0.001
  } else if (isJpy) {
    pipValue = 1000 / entryPrice // Approximate for USDJPY
    pipSize = 0.001
  } else {
    pipValue = 10 // Standard forex lot
    pipSize = 0.0001
  }
  
  const slPips = slDistance / pipSize
  const lotSize = riskAmount / (slPips * pipValue)
  
  // Round to 2 decimal places
  return Math.round(lotSize * 100) / 100
}

export interface RRParams {
  entryPrice: number
  stopLoss: number
  takeProfit: number
  direction: 'Buy' | 'Sell'
}

export function calculateRR(params: RRParams): number {
  const { entryPrice, stopLoss, takeProfit } = params
  
  const slDistance = Math.abs(entryPrice - stopLoss)
  const tpDistance = Math.abs(takeProfit - entryPrice)
  
  if (slDistance === 0) return 0
  
  return Math.round((tpDistance / slDistance) * 100) / 100
}

export function calculatePips(entryPrice: number, exitPrice: number, pair: string): number {
  const isJpy = pair.includes('JPY')
  const isGold = pair.includes('XAU') || pair.includes('GOLD')
  
  let multiplier: number
  if (isGold) {
    multiplier = 100 // 2 decimals for gold
  } else if (isJpy) {
    multiplier = 100 // 3 decimals for JPY pairs
  } else {
    multiplier = 10000 // 5 decimals for standard forex
  }
  
  return Math.round(Math.abs(exitPrice - entryPrice) * multiplier * 10) / 10
}

export function calculateProfitLoss(
  entryPrice: number,
  exitPrice: number,
  lotSize: number,
  direction: 'Buy' | 'Sell',
  pair: string
): number {
  const pips = calculatePips(entryPrice, exitPrice, pair)
  const isGold = pair.includes('XAU') || pair.includes('GOLD')
  const pipValue = isGold ? 10 : 10 // $10 per pip per lot
  
  const rawProfit = pips * pipValue * lotSize
  return direction === 'Buy' 
    ? (exitPrice > entryPrice ? rawProfit : -rawProfit)
    : (exitPrice < entryPrice ? rawProfit : -rawProfit)
}

// ============================================
// STATISTICS FUNCTIONS
// ============================================

export function calculateWinRate(wins: number, total: number): number {
  if (total === 0) return 0
  return Math.round((wins / total) * 100 * 100) / 100
}

export function calculateProfitFactor(grossProfit: number, grossLoss: number): number {
  if (grossLoss === 0) return grossProfit > 0 ? Infinity : 0
  return Math.round((grossProfit / Math.abs(grossLoss)) * 100) / 100
}

export function calculateMaxDrawdown(equityHistory: number[]): number {
  if (equityHistory.length < 2) return 0
  
  let maxDrawdown = 0
  let peak = equityHistory[0]
  
  for (const equity of equityHistory) {
    if (equity > peak) {
      peak = equity
    }
    const drawdown = ((peak - equity) / peak) * 100
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown
    }
  }
  
  return Math.round(maxDrawdown * 100) / 100
}

export function calculateAverageRR(trades: { rr: number; result: string }[]): number {
  if (trades.length === 0) return 0
  const total = trades.reduce((sum, trade) => sum + trade.rr, 0)
  return Math.round((total / trades.length) * 100) / 100
}

export function calculateExpectancy(
  winRate: number,
  avgWin: number,
  avgLoss: number
): number {
  return (winRate / 100) * avgWin - (1 - winRate / 100) * Math.abs(avgLoss)
}

// ============================================
// SIGNAL FUNCTIONS
// ============================================

export interface SignalValidation {
  isValid: boolean
  errors: string[]
  warnings: string[]
}

export function validateSignal(
  rr: number,
  spread: number,
  adrPercent: number,
  dailyLoss: number,
  maxDailyLoss: number
): SignalValidation {
  const errors: string[] = []
  const warnings: string[] = []
  
  // RR validation
  if (rr < 2) {
    errors.push('Risk/Reward ratio must be at least 1:2')
  }
  
  // Spread validation
  if (spread > 5) {
    warnings.push('Spread is higher than normal')
  }
  
  // ADR validation
  if (adrPercent > 90) {
    warnings.push('Price has moved >90% of ADR')
  }
  
  // Daily loss validation
  const dailyLossPercent = (dailyLoss / maxDailyLoss) * 100
  if (dailyLossPercent >= 100) {
    errors.push('Daily loss limit exceeded - trading blocked')
  } else if (dailyLossPercent >= 80) {
    warnings.push('Approaching daily loss limit')
  }
  
  return {
    isValid: errors.length === 0,
    errors,
    warnings
  }
}

export function calculateSignalStrength(
  confluences: string[],
  setupQuality: number,
  rr: number
): number {
  let strength = 0
  
  // Confluence score (max 40)
  strength += Math.min(confluences.length * 8, 40)
  
  // Setup quality score (max 30)
  strength += (setupQuality / 100) * 30
  
  // RR score (max 30)
  if (rr >= 3) strength += 30
  else if (rr >= 2.5) strength += 25
  else if (rr >= 2) strength += 20
  else if (rr >= 1.5) strength += 15
  else strength += 10
  
  return Math.round(strength)
}

// ============================================
// GRADE FUNCTIONS
// ============================================

export type TradeGrade = 'A' | 'B' | 'C' | 'D'

export function calculateTradeGrade(params: {
  rulesFollowed: boolean
  setupQuality: number
  emotion: string
  rrAchieved: number
}): { grade: TradeGrade; score: number } {
  let score = 0
  
  // Rules followed (40 points)
  if (params.rulesFollowed) score += 40
  
  // Setup quality (30 points)
  score += (params.setupQuality / 100) * 30
  
  // Emotion (15 points)
  if (params.emotion === 'Calm') score += 15
  else if (['Overconfidence', 'Hesitation'].includes(params.emotion)) score += 8
  
  // RR achieved (15 points)
  if (params.rrAchieved >= 3) score += 15
  else if (params.rrAchieved >= 2) score += 10
  else if (params.rrAchieved >= 1) score += 5
  
  score = Math.round(score)
  
  let grade: TradeGrade
  if (score >= 90) grade = 'A'
  else if (score >= 75) grade = 'B'
  else if (score >= 60) grade = 'C'
  else grade = 'D'
  
  return { grade, score }
}

// ============================================
// TIME FUNCTIONS
// ============================================

export function getTradingSession(): string {
  const hour = new Date().getUTCHours()
  
  if (hour >= 0 && hour < 8) return 'Asian'
  if (hour >= 8 && hour < 12) return 'London'
  if (hour >= 12 && hour < 17) return 'New York'
  if (hour >= 17 && hour < 21) return 'London-NY Overlap'
  return 'Low Liquidity'
}

export function isHighImpactNewsTime(): boolean {
  // Simplified - in production, check actual economic calendar
  const hour = new Date().getUTCHours()
  const minutes = new Date().getUTCMinutes()
  
  // Major news typically at 8:30, 10:00, 14:00, 16:00 UTC
  const newsTimes = [
    { hour: 8, minute: 30 },
    { hour: 10, minute: 0 },
    { hour: 14, minute: 0 },
    { hour: 16, minute: 0 },
  ]
  
  return newsTimes.some(nt => 
    Math.abs(hour - nt.hour) === 0 && Math.abs(minutes - nt.minute) <= 30
  )
}

export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes}m`
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  if (hours < 24) return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`
  const days = Math.floor(hours / 24)
  const remainingHours = hours % 24
  return remainingHours > 0 ? `${days}d ${remainingHours}h` : `${days}d`
}
